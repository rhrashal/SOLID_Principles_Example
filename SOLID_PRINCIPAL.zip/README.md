# SOLID.Practice
These samples contains practical examples of applying SOLID principles using C#. These the source code from my workshop demo.   

For more detailed explanations, please visit my blog [here](https://blog-aboelkassem.netlify.app/blog/solid-principles-for-desiging-software).
