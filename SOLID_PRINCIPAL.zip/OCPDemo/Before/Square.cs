﻿namespace OCPDemo.Before
{
    public class Square
    {
        public decimal Side { get; set; }
        public decimal Top { get; set; }
        public decimal Left { get; set; }
    }
}
