﻿namespace OCPDemo.Before
{
    public class Triangle
    {
        public decimal Side1 { get; set; }
        public decimal Side2 { get; set; }
        public decimal Side3 { get; set; }
    }
}
