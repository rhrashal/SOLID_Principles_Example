﻿namespace OCPDemo.After
{
    public interface IShape
    {
        void Draw();
    }
}
