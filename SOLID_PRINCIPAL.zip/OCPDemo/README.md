# SOLID.Practice
These samples contains practical examples of applying SOLID principles using C#. These the source code from my workshop demo.   

For more detailed explanations, please visit my blog [here](https://blog-aboelkassem.netlify.app/blog/solid-principles-for-desiging-software).



### The SOLID principle was introduced by Robert C. Martin, also known as Uncle Bob and it is a coding standard in programming. This principle is an acronym of the five principles which are given below:

## Single Responsibility Principle (SRP)
## Open/Closed Principle
## Liskov�s Substitution Principle (LSP)
## Interface Segregation Principle (ISP)
## Dependency Inversion Principle (DIP)









# Open/Closed Principle (OCP)
Software entities(modules, classes, methods) should be open for extension but closed for modification.
any new functionality should be done by adding new classes instead of changing an existing one
## Why Should Code be closed to modification?
Less Likely to introduce bugs in code we don�t touch
Less Likely to break dependent code when we don�t have to deploy updates
Fewer conditionals in code that is open to extension results in simpler code
All the attributes and behaviors are encapsulated
Proven to be stable within your system
Bug Fixes are ok
closed does not mean that changes cannot be made to a class during development. It happens when most of the design decisions have been finalized and once you have implemented most of your system.

## How can you predict future changes
start concrete and modify the code the first time or two
by the third modification, consider making the code open to extension for that axis of change
## How to Implement OCP
adding new functionality to derived class (abstract class)
or allow the client to access the original class with an abstract interface
### 1- Abstract Class
first, make the base class that contains the original method abstract class and make the method abstract method don�t have an implementation,
Create class/classes inherit from this abstract class to do these abstract method in different functionality � so now it�s close for modifications and open for an extension new method
ocp-abstract.png

### 2- Interface
Create an interface that contains the common method that wants to add new functionality to it
Create class/classes implement this interface to do the different functionalities for this method
ocp-interface.png

### Other Typical Approaches to OCP
1- Parameters
2- Inheritance
3- Composition/ Injection
Applying these approaches to this simple code