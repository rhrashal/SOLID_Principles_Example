﻿using ISPDemo.Models;

namespace ISPDemo.After
{
    interface IScanner
    {
        void Scan(List<Document> documents);
    }
}
