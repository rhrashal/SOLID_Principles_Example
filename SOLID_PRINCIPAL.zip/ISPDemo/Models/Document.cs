﻿namespace ISPDemo.Models
{
    public class Document
    {
        public Document(string text)
        {
            Text = text;
        }
        public string Text { get; set; }
    }
}
