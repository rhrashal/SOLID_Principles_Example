# SOLID.Practice
These samples contains practical examples of applying SOLID principles using C#. These the source code from my workshop demo.   

For more detailed explanations, please visit my blog [here](https://blog-aboelkassem.netlify.app/blog/solid-principles-for-desiging-software).



### The SOLID principle was introduced by Robert C. Martin, also known as Uncle Bob and it is a coding standard in programming. This principle is an acronym of the five principles which are given below:

## Single Responsibility Principle (SRP)
## Open/Closed Principle
## Liskov�s Substitution Principle (LSP)
## Interface Segregation Principle (ISP)
## Dependency Inversion Principle (DIP)



### Interface Segregation Principle (ISP)
uncle bob said �Clients should not be forced to depend on methods they do not use�
Many client-specific interfaces are better than one general-purpose interface.

avoid fat interface so prefer small
Client must not implement unnecessary methods