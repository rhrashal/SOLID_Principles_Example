# SOLID.Practice
These samples contains practical examples of applying SOLID principles using C#. These the source code from my workshop demo.   

For more detailed explanations, please visit my blog [here](https://blog-aboelkassem.netlify.app/blog/solid-principles-for-desiging-software).



### The SOLID principle was introduced by Robert C. Martin, also known as Uncle Bob and it is a coding standard in programming. This principle is an acronym of the five principles which are given below:

## Single Responsibility Principle (SRP)
## Open/Closed Principle
## Liskov�s Substitution Principle (LSP)
## Interface Segregation Principle (ISP)
## Dependency Inversion Principle (DIP)


### Single Responsibility Principle (SRP)
Single Responsibility Principle (SRP)
The Code/Class/Method �do one thing and do it well�
Uncle Bob, �There should never be more than one reason for a class to change�
A Class or method Should have one and only one reason to change, meaning that a class should have only one job or responsible for one part of the functionality