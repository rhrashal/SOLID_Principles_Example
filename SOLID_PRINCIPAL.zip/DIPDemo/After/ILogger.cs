﻿namespace DIPDemo.After
{
    public interface ILogger
    {
        void LogEvent(string message, string category);
    }
}
