# SOLID.Practice
These samples contains practical examples of applying SOLID principles using C#. These the source code from my workshop demo.   

For more detailed explanations, please visit my blog [here](https://blog-aboelkassem.netlify.app/blog/solid-principles-for-desiging-software).



### The SOLID principle was introduced by Robert C. Martin, also known as Uncle Bob and it is a coding standard in programming. This principle is an acronym of the five principles which are given below:

## Single Responsibility Principle (SRP)
## Open/Closed Principle
## Liskov�s Substitution Principle (LSP)
## Interface Segregation Principle (ISP)
## Dependency Inversion Principle (DIP)






### Dependency Inversion Principle (DIP)
The principle states that high-level modules should depend on high-level generalizations, and not on low-level details. This means your class should depend on Interface or Abstract class, not a concrete class. Interfaces and Abstract classes are high-level resources. A concrete class is a low-level resource.

High-Level Modules should not depend upon Low-Level Modules. Both should depend upon abstractions.

abstractions should not depend on details
details should depend on abstractions dpi.png
Applying this principle would make your code loosely coupling and highly cohesive (don�t depend on low-level classes)
High-level Module is the module that has business rules, more abstract, process-oriented, further from (I/O) while Low-Level Module is closer to (I/O) and interacts with specific external systems and hardware (keep plumbing code separate from high-level business logic)
Low-Level Dependencies like Database, File system, Email, Web APIs, Configuration and Clock
This principle name �Dependency Inversion� for studying in a book, but in actual coding called �dependency injection� like in asp.net core that is completely depend on it and follow it
dependency injection (DI) says don�t create your own dependencies instead you should depend on abstractions and request those dependencies from the client. there are three methods on how to apply that

Constructor arguments (Prefer one because it follows explicit dependencies principle)
Properties injection
Method Constructor